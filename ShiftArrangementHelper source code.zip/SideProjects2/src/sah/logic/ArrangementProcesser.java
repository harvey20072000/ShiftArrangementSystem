package sah.logic;

import java.util.Map;

import sah.model.ArrangementPerDay;
import sah.model.Attender;

public interface ArrangementProcesser {

	/**
	 * 生成初始排班表
	 * @param arrangements
	 * @param attendersMap
	 * @throws Exception
	 */
	void genArrangements(Map<Long, ArrangementPerDay> arrangements, Map<String, Attender> attendersMap) throws Exception;
	
}
