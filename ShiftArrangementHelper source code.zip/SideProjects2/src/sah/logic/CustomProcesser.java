package sah.logic;

import java.util.Map;

import sah.model.ArrangementPerDay;
import sah.model.Attender;

public interface CustomProcesser {

	void adjustArrangements(Map<Long, ArrangementPerDay> arrangements, Map<String, Attender> attendersMap) throws Exception;
	
}
