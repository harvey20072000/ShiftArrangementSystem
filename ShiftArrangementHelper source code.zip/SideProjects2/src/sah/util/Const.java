package sah.util;


public class Const {
	public final static String DEFAULT_CHARSET = "utf-8";
	
	public final static String DATE_FORMAT_FULL = "yyyy/MM/dd HH:mm:ss";
}
